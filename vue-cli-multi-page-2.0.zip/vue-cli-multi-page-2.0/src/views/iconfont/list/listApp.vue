<template>
  <div class="mainWarp">
		<hb-head headfont="iconfont 字体"></hb-head>
  	<div id="">
  		<div class="main markdown">
       	
       	<div class="pad10 color666 font12">
       			<p>
       				这里仅显示部分字体图标，也可自行到官网下载。	<a href="http://www.iconfont.cn/" target="_blank">http://www.iconfont.cn/</a>
       			</p>
       			<p>
       				图标的颜色可以自行更改。
       			</p>
       	</div>
       	
        <ul class="icon_lists bgfff overflow pad10 clear">
            
                <li>
                <i class="icon iconfont">&#xe6e9;</i>
                    <div class="name">设置</div>
                    <div class="code">&amp;#xe6e9;</div>
                </li>
            
                <li>
                <i class="icon iconfont" style="color: #FF0000;">&#xe6ea;</i>
                    <div class="name">设置</div>
                    <div class="code">&amp;#xe6ea;</div>
                </li>
            
                <li>
                <i class="icon iconfont" style="color: #16C2C2;">&#xe6eb;</i>
                    <div class="name">删除</div>
                    <div class="code">&amp;#xe6eb;</div>
                </li>
            
                <li>
                <i class="icon iconfont" style="color: #FDDD9B;">&#xe6ec;</i>
                    <div class="name">刷新</div>
                    <div class="code">&amp;#xe6ec;</div>
                </li>
            
                <li>
                <i class="icon iconfont" style="color: #23B42A;">&#xe600;</i>
                    <div class="name">微信</div>
                    <div class="code">&amp;#xe600;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6df;</i>
                    <div class="name">下载</div>
                    <div class="code">&amp;#xe6df;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6d2;</i>
                    <div class="name">购物车</div>
                    <div class="code">&amp;#xe6d2;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe601;</i>
                    <div class="name">round_check</div>
                    <div class="code">&amp;#xe601;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe602;</i>
                    <div class="name">round_close_fill</div>
                    <div class="code">&amp;#xe602;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe603;</i>
                    <div class="name">round_close</div>
                    <div class="code">&amp;#xe603;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe604;</i>
                    <div class="name">round_right_fill</div>
                    <div class="code">&amp;#xe604;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe605;</i>
                    <div class="name">round_right</div>
                    <div class="code">&amp;#xe605;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe606;</i>
                    <div class="name">search</div>
                    <div class="code">&amp;#xe606;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe607;</i>
                    <div class="name">taxi</div>
                    <div class="code">&amp;#xe607;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe608;</i>
                    <div class="name">time_fill</div>
                    <div class="code">&amp;#xe608;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe609;</i>
                    <div class="name">time</div>
                    <div class="code">&amp;#xe609;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe60a;</i>
                    <div class="name">unfold</div>
                    <div class="code">&amp;#xe60a;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe60b;</i>
                    <div class="name">warn_fill</div>
                    <div class="code">&amp;#xe60b;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe60c;</i>
                    <div class="name">warn</div>
                    <div class="code">&amp;#xe60c;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe60d;</i>
                    <div class="name">camera_fill</div>
                    <div class="code">&amp;#xe60d;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe60e;</i>
                    <div class="name">camera</div>
                    <div class="code">&amp;#xe60e;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe60f;</i>
                    <div class="name">comment_fill</div>
                    <div class="code">&amp;#xe60f;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe610;</i>
                    <div class="name">comment</div>
                    <div class="code">&amp;#xe610;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe611;</i>
                    <div class="name">like_fill</div>
                    <div class="code">&amp;#xe611;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe612;</i>
                    <div class="name">like</div>
                    <div class="code">&amp;#xe612;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe613;</i>
                    <div class="name">notification_fill</div>
                    <div class="code">&amp;#xe613;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe614;</i>
                    <div class="name">notification</div>
                    <div class="code">&amp;#xe614;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe615;</i>
                    <div class="name">order</div>
                    <div class="code">&amp;#xe615;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe616;</i>
                    <div class="name">same_fill</div>
                    <div class="code">&amp;#xe616;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe617;</i>
                    <div class="name">same</div>
                    <div class="code">&amp;#xe617;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe618;</i>
                    <div class="name">deliver</div>
                    <div class="code">&amp;#xe618;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe619;</i>
                    <div class="name">evaluate</div>
                    <div class="code">&amp;#xe619;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe61a;</i>
                    <div class="name">pay</div>
                    <div class="code">&amp;#xe61a;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe61b;</i>
                    <div class="name">send</div>
                    <div class="code">&amp;#xe61b;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe61c;</i>
                    <div class="name">shop</div>
                    <div class="code">&amp;#xe61c;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe61d;</i>
                    <div class="name">ticket</div>
                    <div class="code">&amp;#xe61d;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe61e;</i>
                    <div class="name">wang</div>
                    <div class="code">&amp;#xe61e;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe61f;</i>
                    <div class="name">back</div>
                    <div class="code">&amp;#xe61f;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe620;</i>
                    <div class="name">cascades</div>
                    <div class="code">&amp;#xe620;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe621;</i>
                    <div class="name">discover</div>
                    <div class="code">&amp;#xe621;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe622;</i>
                    <div class="name">list</div>
                    <div class="code">&amp;#xe622;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe623;</i>
                    <div class="name">more</div>
                    <div class="code">&amp;#xe623;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe624;</i>
                    <div class="name">my_fill</div>
                    <div class="code">&amp;#xe624;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe625;</i>
                    <div class="name">my</div>
                    <div class="code">&amp;#xe625;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6d4;</i>
                    <div class="name">电话</div>
                    <div class="code">&amp;#xe6d4;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6e0;</i>
                    <div class="name">外卖餐饮</div>
                    <div class="code">&amp;#xe6e0;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe626;</i>
                    <div class="name">explore_fill</div>
                    <div class="code">&amp;#xe626;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe627;</i>
                    <div class="name">fold</div>
                    <div class="code">&amp;#xe627;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe628;</i>
                    <div class="name">game</div>
                    <div class="code">&amp;#xe628;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe629;</i>
                    <div class="name">redpacket</div>
                    <div class="code">&amp;#xe629;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe62a;</i>
                    <div class="name">selection_fill</div>
                    <div class="code">&amp;#xe62a;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe62b;</i>
                    <div class="name">similar</div>
                    <div class="code">&amp;#xe62b;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe62c;</i>
                    <div class="name">appreciate_fill</div>
                    <div class="code">&amp;#xe62c;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe62d;</i>
                    <div class="name">info_fill</div>
                    <div class="code">&amp;#xe62d;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe62e;</i>
                    <div class="name">info</div>
                    <div class="code">&amp;#xe62e;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe62f;</i>
                    <div class="name">forward_fill</div>
                    <div class="code">&amp;#xe62f;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe630;</i>
                    <div class="name">forward</div>
                    <div class="code">&amp;#xe630;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe631;</i>
                    <div class="name">recharge_fill</div>
                    <div class="code">&amp;#xe631;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe632;</i>
                    <div class="name">recharge</div>
                    <div class="code">&amp;#xe632;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe633;</i>
                    <div class="name">vipcard</div>
                    <div class="code">&amp;#xe633;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe634;</i>
                    <div class="name">voice</div>
                    <div class="code">&amp;#xe634;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe635;</i>
                    <div class="name">voice_fill</div>
                    <div class="code">&amp;#xe635;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe636;</i>
                    <div class="name">friend_favor</div>
                    <div class="code">&amp;#xe636;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe637;</i>
                    <div class="name">wifi</div>
                    <div class="code">&amp;#xe637;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe638;</i>
                    <div class="name">share</div>
                    <div class="code">&amp;#xe638;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe639;</i>
                    <div class="name">we_fill</div>
                    <div class="code">&amp;#xe639;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe63a;</i>
                    <div class="name">we</div>
                    <div class="code">&amp;#xe63a;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe63b;</i>
                    <div class="name">light_auto</div>
                    <div class="code">&amp;#xe63b;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe63c;</i>
                    <div class="name">light_forbid</div>
                    <div class="code">&amp;#xe63c;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe63d;</i>
                    <div class="name">light_fill</div>
                    <div class="code">&amp;#xe63d;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe63e;</i>
                    <div class="name">camera_rotate</div>
                    <div class="code">&amp;#xe63e;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe63f;</i>
                    <div class="name">light</div>
                    <div class="code">&amp;#xe63f;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe640;</i>
                    <div class="name">bar_code</div>
                    <div class="code">&amp;#xe640;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe641;</i>
                    <div class="name">flashlight_close</div>
                    <div class="code">&amp;#xe641;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe642;</i>
                    <div class="name">flashlight_open</div>
                    <div class="code">&amp;#xe642;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe643;</i>
                    <div class="name">search_list</div>
                    <div class="code">&amp;#xe643;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe644;</i>
                    <div class="name">service</div>
                    <div class="code">&amp;#xe644;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe645;</i>
                    <div class="name">sort</div>
                    <div class="code">&amp;#xe645;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe646;</i>
                    <div class="name">down</div>
                    <div class="code">&amp;#xe646;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe647;</i>
                    <div class="name">mobile</div>
                    <div class="code">&amp;#xe647;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe648;</i>
                    <div class="name">mobile_fill</div>
                    <div class="code">&amp;#xe648;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6d5;</i>
                    <div class="name">电话</div>
                    <div class="code">&amp;#xe6d5;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe649;</i>
                    <div class="name">copy</div>
                    <div class="code">&amp;#xe649;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe64a;</i>
                    <div class="name">countdown_fill</div>
                    <div class="code">&amp;#xe64a;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe64b;</i>
                    <div class="name">countdown</div>
                    <div class="code">&amp;#xe64b;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe64c;</i>
                    <div class="name">notice_fill</div>
                    <div class="code">&amp;#xe64c;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe64d;</i>
                    <div class="name">notice</div>
                    <div class="code">&amp;#xe64d;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe64e;</i>
                    <div class="name">qiang</div>
                    <div class="code">&amp;#xe64e;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe64f;</i>
                    <div class="name">upstage_fill</div>
                    <div class="code">&amp;#xe64f;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe650;</i>
                    <div class="name">upstage</div>
                    <div class="code">&amp;#xe650;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe651;</i>
                    <div class="name">baby_fill</div>
                    <div class="code">&amp;#xe651;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe652;</i>
                    <div class="name">baby</div>
                    <div class="code">&amp;#xe652;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe653;</i>
                    <div class="name">brand_fill</div>
                    <div class="code">&amp;#xe653;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe654;</i>
                    <div class="name">brand</div>
                    <div class="code">&amp;#xe654;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe655;</i>
                    <div class="name">choiceness_fill</div>
                    <div class="code">&amp;#xe655;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe656;</i>
                    <div class="name">choiceness</div>
                    <div class="code">&amp;#xe656;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe657;</i>
                    <div class="name">clothes_fill</div>
                    <div class="code">&amp;#xe657;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe658;</i>
                    <div class="name">clothes</div>
                    <div class="code">&amp;#xe658;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe659;</i>
                    <div class="name">creative_fill</div>
                    <div class="code">&amp;#xe659;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe65a;</i>
                    <div class="name">creative</div>
                    <div class="code">&amp;#xe65a;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe65b;</i>
                    <div class="name">female</div>
                    <div class="code">&amp;#xe65b;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe65c;</i>
                    <div class="name">keyboard</div>
                    <div class="code">&amp;#xe65c;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe65d;</i>
                    <div class="name">male</div>
                    <div class="code">&amp;#xe65d;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe65e;</i>
                    <div class="name">new_fill</div>
                    <div class="code">&amp;#xe65e;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe65f;</i>
                    <div class="name">new</div>
                    <div class="code">&amp;#xe65f;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe660;</i>
                    <div class="name">pull_left</div>
                    <div class="code">&amp;#xe660;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe661;</i>
                    <div class="name">pull_right</div>
                    <div class="code">&amp;#xe661;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe662;</i>
                    <div class="name">rank_fill</div>
                    <div class="code">&amp;#xe662;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe663;</i>
                    <div class="name">rank</div>
                    <div class="code">&amp;#xe663;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe664;</i>
                    <div class="name">bad</div>
                    <div class="code">&amp;#xe664;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe665;</i>
                    <div class="name">camera_add</div>
                    <div class="code">&amp;#xe665;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe666;</i>
                    <div class="name">focus</div>
                    <div class="code">&amp;#xe666;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe667;</i>
                    <div class="name">friend_fill</div>
                    <div class="code">&amp;#xe667;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe668;</i>
                    <div class="name">camera_add_fill</div>
                    <div class="code">&amp;#xe668;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe669;</i>
                    <div class="name">apps</div>
                    <div class="code">&amp;#xe669;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe66a;</i>
                    <div class="name">paint_fill</div>
                    <div class="code">&amp;#xe66a;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe66b;</i>
                    <div class="name">paint</div>
                    <div class="code">&amp;#xe66b;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe66c;</i>
                    <div class="name">pic_fill</div>
                    <div class="code">&amp;#xe66c;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6e3;</i>
                    <div class="name">支付宝</div>
                    <div class="code">&amp;#xe6e3;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe66d;</i>
                    <div class="name">refresh_arrow</div>
                    <div class="code">&amp;#xe66d;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6d6;</i>
                    <div class="name">桌数</div>
                    <div class="code">&amp;#xe6d6;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe66e;</i>
                    <div class="name">mark</div>
                    <div class="code">&amp;#xe66e;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe66f;</i>
                    <div class="name">present_fill</div>
                    <div class="code">&amp;#xe66f;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe670;</i>
                    <div class="name">repeal</div>
                    <div class="code">&amp;#xe670;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6d3;</i>
                    <div class="name">购物车</div>
                    <div class="code">&amp;#xe6d3;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe671;</i>
                    <div class="name">album</div>
                    <div class="code">&amp;#xe671;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe672;</i>
                    <div class="name">people_fill</div>
                    <div class="code">&amp;#xe672;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe673;</i>
                    <div class="name">people</div>
                    <div class="code">&amp;#xe673;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe674;</i>
                    <div class="name">service_fill</div>
                    <div class="code">&amp;#xe674;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe675;</i>
                    <div class="name">repair</div>
                    <div class="code">&amp;#xe675;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe676;</i>
                    <div class="name">file</div>
                    <div class="code">&amp;#xe676;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe677;</i>
                    <div class="name">repair_fill</div>
                    <div class="code">&amp;#xe677;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6e4;</i>
                    <div class="name">银行</div>
                    <div class="code">&amp;#xe6e4;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe678;</i>
                    <div class="name">taoxiaopu</div>
                    <div class="code">&amp;#xe678;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe679;</i>
                    <div class="name">attention_fill</div>
                    <div class="code">&amp;#xe679;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe67a;</i>
                    <div class="name">attention</div>
                    <div class="code">&amp;#xe67a;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe67b;</i>
                    <div class="name">command_fill</div>
                    <div class="code">&amp;#xe67b;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe67c;</i>
                    <div class="name">command</div>
                    <div class="code">&amp;#xe67c;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe67d;</i>
                    <div class="name">community_fill</div>
                    <div class="code">&amp;#xe67d;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe67e;</i>
                    <div class="name">community</div>
                    <div class="code">&amp;#xe67e;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe67f;</i>
                    <div class="name">read</div>
                    <div class="code">&amp;#xe67f;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe680;</i>
                    <div class="name">calendar</div>
                    <div class="code">&amp;#xe680;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe681;</i>
                    <div class="name">cut</div>
                    <div class="code">&amp;#xe681;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe682;</i>
                    <div class="name">magic</div>
                    <div class="code">&amp;#xe682;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe683;</i>
                    <div class="name">backward_fill</div>
                    <div class="code">&amp;#xe683;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe684;</i>
                    <div class="name">forward_fill</div>
                    <div class="code">&amp;#xe684;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe685;</i>
                    <div class="name">play_fill</div>
                    <div class="code">&amp;#xe685;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe686;</i>
                    <div class="name">stop</div>
                    <div class="code">&amp;#xe686;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe687;</i>
                    <div class="name">tag_fill</div>
                    <div class="code">&amp;#xe687;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe688;</i>
                    <div class="name">tag</div>
                    <div class="code">&amp;#xe688;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe689;</i>
                    <div class="name">group</div>
                    <div class="code">&amp;#xe689;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe68a;</i>
                    <div class="name">all</div>
                    <div class="code">&amp;#xe68a;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe68b;</i>
                    <div class="name">back_delete</div>
                    <div class="code">&amp;#xe68b;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe68c;</i>
                    <div class="name">hot_fill</div>
                    <div class="code">&amp;#xe68c;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe68d;</i>
                    <div class="name">hot</div>
                    <div class="code">&amp;#xe68d;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe68e;</i>
                    <div class="name">post</div>
                    <div class="code">&amp;#xe68e;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe68f;</i>
                    <div class="name">radio_box</div>
                    <div class="code">&amp;#xe68f;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe690;</i>
                    <div class="name">round_down</div>
                    <div class="code">&amp;#xe690;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe691;</i>
                    <div class="name">upload</div>
                    <div class="code">&amp;#xe691;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe692;</i>
                    <div class="name">write_fill</div>
                    <div class="code">&amp;#xe692;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe693;</i>
                    <div class="name">write</div>
                    <div class="code">&amp;#xe693;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe694;</i>
                    <div class="name">radio_box_fill</div>
                    <div class="code">&amp;#xe694;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe695;</i>
                    <div class="name">punch</div>
                    <div class="code">&amp;#xe695;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe696;</i>
                    <div class="name">shake</div>
                    <div class="code">&amp;#xe696;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe697;</i>
                    <div class="name">add</div>
                    <div class="code">&amp;#xe697;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe698;</i>
                    <div class="name">move</div>
                    <div class="code">&amp;#xe698;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe699;</i>
                    <div class="name">safe</div>
                    <div class="code">&amp;#xe699;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe69a;</i>
                    <div class="name">activity_fill</div>
                    <div class="code">&amp;#xe69a;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe69b;</i>
                    <div class="name">crown_fill</div>
                    <div class="code">&amp;#xe69b;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe69c;</i>
                    <div class="name">crown</div>
                    <div class="code">&amp;#xe69c;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe69d;</i>
                    <div class="name">goods_fill</div>
                    <div class="code">&amp;#xe69d;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe69e;</i>
                    <div class="name">message_fill</div>
                    <div class="code">&amp;#xe69e;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe69f;</i>
                    <div class="name">profile_fill</div>
                    <div class="code">&amp;#xe69f;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6a0;</i>
                    <div class="name">sound</div>
                    <div class="code">&amp;#xe6a0;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6a1;</i>
                    <div class="name">sponsor_fill</div>
                    <div class="code">&amp;#xe6a1;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6a2;</i>
                    <div class="name">sponsor</div>
                    <div class="code">&amp;#xe6a2;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6a3;</i>
                    <div class="name">up_block</div>
                    <div class="code">&amp;#xe6a3;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6a4;</i>
                    <div class="name">we_block</div>
                    <div class="code">&amp;#xe6a4;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6a5;</i>
                    <div class="name">we_unblock</div>
                    <div class="code">&amp;#xe6a5;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6a6;</i>
                    <div class="name">my</div>
                    <div class="code">&amp;#xe6a6;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6a7;</i>
                    <div class="name">my_fill</div>
                    <div class="code">&amp;#xe6a7;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6e1;</i>
                    <div class="name">订单</div>
                    <div class="code">&amp;#xe6e1;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6d7;</i>
                    <div class="name">桌台</div>
                    <div class="code">&amp;#xe6d7;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6a8;</i>
                    <div class="name">emoji_fill</div>
                    <div class="code">&amp;#xe6a8;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6a9;</i>
                    <div class="name">emoji_flash_fill</div>
                    <div class="code">&amp;#xe6a9;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6aa;</i>
                    <div class="name">flashbuy_fill</div>
                    <div class="code">&amp;#xe6aa;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6ab;</i>
                    <div class="name">text</div>
                    <div class="code">&amp;#xe6ab;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6ac;</i>
                    <div class="name">video_fill</div>
                    <div class="code">&amp;#xe6ac;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6ad;</i>
                    <div class="name">video</div>
                    <div class="code">&amp;#xe6ad;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6ae;</i>
                    <div class="name">goods_favor</div>
                    <div class="code">&amp;#xe6ae;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6af;</i>
                    <div class="name">music_fill</div>
                    <div class="code">&amp;#xe6af;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6b0;</i>
                    <div class="name">music_forbid_fill</div>
                    <div class="code">&amp;#xe6b0;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6b1;</i>
                    <div class="name">xiami_forbid</div>
                    <div class="code">&amp;#xe6b1;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6d8;</i>
                    <div class="name">位置</div>
                    <div class="code">&amp;#xe6d8;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6d9;</i>
                    <div class="name">位置</div>
                    <div class="code">&amp;#xe6d9;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6b2;</i>
                    <div class="name">round_left_fill</div>
                    <div class="code">&amp;#xe6b2;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6b3;</i>
                    <div class="name">triangle_down_fill</div>
                    <div class="code">&amp;#xe6b3;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6b4;</i>
                    <div class="name">triangle_up_fill</div>
                    <div class="code">&amp;#xe6b4;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6b5;</i>
                    <div class="name">round_left_fill</div>
                    <div class="code">&amp;#xe6b5;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6e7;</i>
                    <div class="name">叫醒服务</div>
                    <div class="code">&amp;#xe6e7;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6b6;</i>
                    <div class="name">pull_down</div>
                    <div class="code">&amp;#xe6b6;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6db;</i>
                    <div class="name">密码</div>
                    <div class="code">&amp;#xe6db;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6dc;</i>
                    <div class="name">密码</div>
                    <div class="code">&amp;#xe6dc;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6e5;</i>
                    <div class="name">银联</div>
                    <div class="code">&amp;#xe6e5;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6b7;</i>
                    <div class="name">appreciate_light</div>
                    <div class="code">&amp;#xe6b7;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6b8;</i>
                    <div class="name">emoji_light</div>
                    <div class="code">&amp;#xe6b8;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6b9;</i>
                    <div class="name">goods_light</div>
                    <div class="code">&amp;#xe6b9;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6ba;</i>
                    <div class="name">keyboard_light</div>
                    <div class="code">&amp;#xe6ba;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6bb;</i>
                    <div class="name">record_fill</div>
                    <div class="code">&amp;#xe6bb;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6bc;</i>
                    <div class="name">record_light</div>
                    <div class="code">&amp;#xe6bc;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6bd;</i>
                    <div class="name">record</div>
                    <div class="code">&amp;#xe6bd;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6be;</i>
                    <div class="name">round_add_light</div>
                    <div class="code">&amp;#xe6be;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6bf;</i>
                    <div class="name">sound_light</div>
                    <div class="code">&amp;#xe6bf;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6c0;</i>
                    <div class="name">cardboard_fill</div>
                    <div class="code">&amp;#xe6c0;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6c1;</i>
                    <div class="name">cardboard</div>
                    <div class="code">&amp;#xe6c1;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6c2;</i>
                    <div class="name">form_fill</div>
                    <div class="code">&amp;#xe6c2;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6dd;</i>
                    <div class="name">打勾</div>
                    <div class="code">&amp;#xe6dd;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6c3;</i>
                    <div class="name">coin</div>
                    <div class="code">&amp;#xe6c3;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6c4;</i>
                    <div class="name">sort_light</div>
                    <div class="code">&amp;#xe6c4;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6c5;</i>
                    <div class="name">cardboard_forbid</div>
                    <div class="code">&amp;#xe6c5;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6c6;</i>
                    <div class="name">circle_fill</div>
                    <div class="code">&amp;#xe6c6;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6c7;</i>
                    <div class="name">circle</div>
                    <div class="code">&amp;#xe6c7;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6c8;</i>
                    <div class="name">attention_forbid</div>
                    <div class="code">&amp;#xe6c8;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6c9;</i>
                    <div class="name">attention_forbid_fill</div>
                    <div class="code">&amp;#xe6c9;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6ca;</i>
                    <div class="name">attention_favor_fill</div>
                    <div class="code">&amp;#xe6ca;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6cb;</i>
                    <div class="name">attention_favor</div>
                    <div class="code">&amp;#xe6cb;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6cc;</i>
                    <div class="name">profile_light</div>
                    <div class="code">&amp;#xe6cc;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6cd;</i>
                    <div class="name">pic_light</div>
                    <div class="code">&amp;#xe6cd;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6ce;</i>
                    <div class="name">shop_light</div>
                    <div class="code">&amp;#xe6ce;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6cf;</i>
                    <div class="name">voice_light</div>
                    <div class="code">&amp;#xe6cf;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6d0;</i>
                    <div class="name">attention_favor_fill</div>
                    <div class="code">&amp;#xe6d0;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6d1;</i>
                    <div class="name">camera_light</div>
                    <div class="code">&amp;#xe6d1;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6e8;</i>
                    <div class="name">座位</div>
                    <div class="code">&amp;#xe6e8;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6da;</i>
                    <div class="name">大餐桌</div>
                    <div class="code">&amp;#xe6da;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6e2;</i>
                    <div class="name">外卖</div>
                    <div class="code">&amp;#xe6e2;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6de;</i>
                    <div class="name">打勾</div>
                    <div class="code">&amp;#xe6de;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6e6;</i>
                    <div class="name">现金</div>
                    <div class="code">&amp;#xe6e6;</div>
                </li>
            
                <li>
                <i class="icon iconfont">&#xe6ed;</i>
                    <div class="name">钱箱-02</div>
                    <div class="code">&amp;#xe6ed;</div>
                </li>
            
        </ul>
  	</div>
  
  
  </div>
  </div>
</template>

<script>

import Lib from 'assets/js/Lib';

import HbHead from 'components/HbHead';

export default {

  components: {
    HbHead
  },
  data () {
    return {
      
    }
  },
  methods: {

  }
}
</script>

<style lang="less">

.markdown{
	overflow: hidden;
}
.markdown li{
	float: left;
	width: 25%;
	height: 100px;
	text-align: center;
}

.markdown li .icon{
	font-size: 28px;
}

.markdown li .name{
	font-size: 12px;
	padding: 10px 0;
}

.markdown li .code{
	font-size: 12px;
}

</style>
