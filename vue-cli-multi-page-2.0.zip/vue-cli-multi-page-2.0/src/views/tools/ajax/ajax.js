
import Vue from 'vue'
import App from './ajaxApp'



new Vue({
  render: h => h(App)
}).$mount('#app')
