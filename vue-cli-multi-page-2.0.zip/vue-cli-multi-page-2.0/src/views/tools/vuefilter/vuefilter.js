
import Vue from 'vue'
import App from './vuefilterApp'



new Vue({
  render: h => h(App)
}).$mount('#app')
