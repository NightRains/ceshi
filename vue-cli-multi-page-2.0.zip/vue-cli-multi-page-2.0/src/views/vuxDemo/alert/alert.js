
import Vue from 'vue'
import App from './alertApp'



new Vue({
  render: h => h(App)
}).$mount('#app')
