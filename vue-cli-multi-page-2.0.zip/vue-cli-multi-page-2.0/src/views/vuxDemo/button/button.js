
import Vue from 'vue'
import App from './buttonApp'

new Vue({
  render: h => h(App)
}).$mount('#app')
