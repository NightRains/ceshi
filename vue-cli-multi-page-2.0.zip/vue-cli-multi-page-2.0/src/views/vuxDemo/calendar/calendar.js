
import Vue from 'vue'
import App from './calendarApp'


new Vue({
  render: h => h(App)
}).$mount('#app')
